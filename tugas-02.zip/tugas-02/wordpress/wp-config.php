<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tugas-02');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'zcRf{`?V>8hHSDX^01SH?:v~D9CWlECOL-aABQv:i!7EHh*:W]1HB-$6Hs/F }fD');
define('SECURE_AUTH_KEY',  'fsD}`[P}IA^_(CRqg&*B_&ope:IS9y$>;Hjg&UrbrmjNxREUcsYVs#AF/`llt,Ky');
define('LOGGED_IN_KEY',    '@_+;oEt:pJUB|>i<x>?+ ,0(dw%)`:E/C5V<SUCGNv>zxp1.jS=R!:ax~Y~@cSXh');
define('NONCE_KEY',        'z9!B,!#&.Dh;+2I@53R:4wmuAw`[:Ov_%Av}7{tMaJ8pRQlV;iS7o@?F%]+@9Tdt');
define('AUTH_SALT',        'V4g>u.}Z<qQt_-uS*uUd+DDQZ7g=e-syR&`cK`DwMAbe# h9}YXRx+J D2=!|k 5');
define('SECURE_AUTH_SALT', 'U#h%OIX^FLP5mW%9!TAHye]3M!09xE3x^eiwefIW.p&28s>.JIKQWn[,B4TZy-xP');
define('LOGGED_IN_SALT',   '|6>KxyufE~5`r>L_LHOD:L%otk~w?5 *@B1?P/OSr:O|T`GRMM(dMjj2h6w&=qoW');
define('NONCE_SALT',       '1TKs0oi/= $&V6WmOH[:p~a:W%8{6|~&s6xW:Bu=-3vcOU O~L:cA]XAf72a.*XH');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
